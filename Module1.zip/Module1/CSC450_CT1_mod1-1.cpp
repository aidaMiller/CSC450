#include <iostream>
// Standard namespace declaration
using namespace std;
// Main Function
int main()
{
  // Standard Ouput Statement
  cout << "Welcome to this C++ Program" << endl;
  cout << "I have corrected all errors for this program." << endl;
  return 0;
}
