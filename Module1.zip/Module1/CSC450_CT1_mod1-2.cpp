#include <iostream>
using namespace std;

int main()
{
  double myMoney = 1000.50; // this should be printed out

  cout << "Please be sure to correct all syntax errors in this program" << endl;
  cout << "I have corrected all errors for this program." << endl;
  cout << "The total amount of money available is = " << myMoney << endl;

  return 0;
}
