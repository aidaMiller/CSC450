#include <iostream>
using namespace std;

int main()
{
  string firstName = "Marilyn ";
  string lastName = "Monroe";
  int streetNumber = 12305;
  string streetName = " Fifth Helena Dr.";
  string city = "Los Angeles, ";
  string state = "CA. ";
  int zipCode = 90049;

  cout << "First Name:\t" << firstName << endl;
  cout << "Last Name:\t" << lastName << endl;
  cout << "Street Address:\t" << streetNumber << streetName << endl;
  cout << "City:\t\t" << city << state << endl;
  cout << "Zip code:\t" << zipCode << endl;
}